/* Horizon TV - adaptador Android.
   So ativa dentro do APK (onde existe window.HorizonAndroid).
   Finge ser o PalmServiceBridge da LG: o app.js continua igual. */
(function () {
  if (!window.HorizonAndroid) return;

  var pending = {}, seq = 0;

  // chamado pelo Java com a resposta
  window.__hzCb = function (id, json) {
    var b = pending[id];
    delete pending[id];
    if (b && typeof b.onservicecallback === "function") {
      try { b.onservicecallback(json); } catch (e) {}
    }
  };

  window.PalmServiceBridge = function () {
    var self = this;
    this.onservicecallback = null;
    this.call = function (uri, payload) {
      var id = String(++seq);
      pending[id] = self;
      window.HorizonAndroid.call(id, String(uri), payload || "{}");
    };
    this.cancel = function () {};
  };

  // chamado pelo Java quando uma tecla do controle e apertada
  window.__hzKey = function (code) {
    var e = new KeyboardEvent("keydown", { bubbles: true, cancelable: true });
    try {
      Object.defineProperty(e, "keyCode", { get: function () { return code; } });
      Object.defineProperty(e, "which",   { get: function () { return code; } });
    } catch (x) {}
    document.dispatchEvent(e);
  };

  document.documentElement.classList.add("android");
})();
