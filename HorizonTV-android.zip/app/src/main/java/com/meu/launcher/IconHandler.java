package com.meu.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.webkit.WebResourceResponse;

import androidx.webkit.WebViewAssetLoader;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.util.HashMap;
import java.util.Map;

/** Serve https://appassets.androidplatform.net/pkgicon/<pacote> com o icone do app instalado. */
class IconHandler implements WebViewAssetLoader.PathHandler {

    private final Context ctx;

    IconHandler(Context ctx) {
        this.ctx = ctx;
    }

    @Override
    public WebResourceResponse handle(String path) {
        try {
            String pkg = path;
            int q = pkg.indexOf('?');
            if (q >= 0) pkg = pkg.substring(0, q);
            Drawable d = ctx.getPackageManager().getApplicationIcon(pkg);
            int size = 192;
            Bitmap bmp = Bitmap.createBitmap(size, size, Bitmap.Config.ARGB_8888);
            Canvas c = new Canvas(bmp);
            d.setBounds(0, 0, size, size);
            d.draw(c);
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out);
            Map<String, String> headers = new HashMap<String, String>();
            headers.put("Cache-Control", "max-age=86400");
            return new WebResourceResponse("image/png", null, 200, "OK", headers,
                    new ByteArrayInputStream(out.toByteArray()));
        } catch (Throwable t) {
            return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                    new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
        }
    }
}
