package com.meu.launcher;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.KeyEvent;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.webkit.WebViewAssetLoader;

public class MainActivity extends Activity {

    static final String HOST = "appassets.androidplatform.net";

    /** true = a animacao de entrada toca de novo toda vez que apertar Home. */
    static final boolean REPLAY_INTRO_ON_HOME = false;

    private WebView web;

    @Override
    protected void onCreate(Bundle state) {
        super.onCreate(state);

        web = new WebView(this);
        web.setBackgroundColor(Color.parseColor("#050914"));
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);   // som da entrada
        s.setUseWideViewPort(true);                     // respeita width=1920 do index.html
        s.setLoadWithOverviewMode(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);

        final WebViewAssetLoader loader = new WebViewAssetLoader.Builder()
                .setDomain(HOST)
                .addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this))
                .addPathHandler("/pkgicon/", new IconHandler(this))
                .build();

        web.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                return loader.shouldInterceptRequest(r.getUrl());
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) {
                return !HOST.equals(r.getUrl().getHost());   // nao deixa a pagina navegar para fora
            }
        });

        web.addJavascriptInterface(new Bridge(this, web), "HorizonAndroid");
        web.loadUrl("https://" + HOST + "/assets/index.html");
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        if (REPLAY_INTRO_ON_HOME && web != null) {
            web.evaluateJavascript("document.dispatchEvent(new Event('webOSRelaunch'))", null);
        }
    }

    /** Controle remoto -> codigos de tecla que o app.js (feito para webOS) ja entende. */
    private int mapKey(int k) {
        switch (k) {
            case KeyEvent.KEYCODE_DPAD_LEFT:   return 37;
            case KeyEvent.KEYCODE_DPAD_UP:     return 38;
            case KeyEvent.KEYCODE_DPAD_RIGHT:  return 39;
            case KeyEvent.KEYCODE_DPAD_DOWN:   return 40;
            case KeyEvent.KEYCODE_DPAD_CENTER:
            case KeyEvent.KEYCODE_ENTER:
            case KeyEvent.KEYCODE_NUMPAD_ENTER: return 13;
            case KeyEvent.KEYCODE_BACK:        return 461;
            case KeyEvent.KEYCODE_ESCAPE:      return 27;
            case KeyEvent.KEYCODE_PROG_RED:
            case KeyEvent.KEYCODE_F1:
            case KeyEvent.KEYCODE_MENU:        return 403;   // vermelho = Config.
            case KeyEvent.KEYCODE_PROG_GREEN:
            case KeyEvent.KEYCODE_F2:          return 404;   // verde = Lifestyle
            case KeyEvent.KEYCODE_PROG_YELLOW:
            case KeyEvent.KEYCODE_F3:          return 405;   // amarelo = Visual
            case KeyEvent.KEYCODE_PROG_BLUE:
            case KeyEvent.KEYCODE_F4:          return 406;   // azul = diagnostico
            default: return 0;
        }
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent e) {
        int code = mapKey(e.getKeyCode());
        if (code > 0) {
            if (e.getAction() == KeyEvent.ACTION_DOWN && web != null) {
                web.evaluateJavascript("window.__hzKey&&window.__hzKey(" + code + ")", null);
            }
            return true;
        }
        return super.dispatchKeyEvent(e);
    }
}
