package com.meu.launcher;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.media.AudioManager;
import android.media.tv.TvContract;
import android.media.tv.TvInputInfo;
import android.media.tv.TvInputManager;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.provider.Settings;
import android.webkit.JavascriptInterface;
import android.webkit.WebView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Faz o papel dos servicos "luna://" da LG. O platform-android.js finge ser o
 * PalmServiceBridge e manda cada chamada para ca; a resposta volta no mesmo
 * formato JSON que o app.js ja espera.
 */
public class Bridge {

    private static final Map<String, String> LEGACY = new HashMap<String, String>();
    static {
        // IDs de webOS que o catalogo usa -> pacote Android (so se nao achar pelo nome)
        LEGACY.put("netflix", "com.netflix.ninja");
        LEGACY.put("youtube.leanback.v4", "com.google.android.youtube.tv");
        LEGACY.put("amazon", "com.amazon.amazonvideo.livingroom");
        LEGACY.put("com.disney.disneyplus-prod", "com.disney.disneyplus");
        LEGACY.put("spotify-beehive", "com.spotify.tv.android");
    }

    private final Activity act;
    private final WebView web;
    private final ExecutorService pool = Executors.newFixedThreadPool(2);

    Bridge(Activity act, WebView web) {
        this.act = act;
        this.web = web;
    }

    @JavascriptInterface
    public void call(final String id, final String uri, final String payload) {
        pool.execute(new Runnable() {
            @Override
            public void run() {
                String out;
                try {
                    JSONObject p = (payload == null || payload.length() == 0)
                            ? new JSONObject() : new JSONObject(payload);
                    out = route(uri, p);
                } catch (Throwable t) {
                    out = fail(String.valueOf(t.getMessage()));
                }
                reply(id, out);
            }
        });
    }

    private void reply(String id, String json) {
        final String js = "window.__hzCb(" + JSONObject.quote(id) + "," + JSONObject.quote(json) + ")";
        act.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                web.evaluateJavascript(js, null);
            }
        });
    }

    // ------------------------------------------------------------

    private String route(String uri, JSONObject p) throws Exception {
        if (uri.equals("luna://com.webos.applicationManager/launch")) return launch(p);
        if (uri.equals("luna://com.webos.applicationManager/listLaunchPoints")) return listApps();
        if (uri.equals("luna://com.webos.applicationManager/listApps")) return "{\"returnValue\":true,\"apps\":[]}";
        if (uri.equals("luna://com.webos.audio/getVolume")) return getVolume();
        if (uri.equals("luna://com.webos.audio/setVolume")) return setVolume(p);
        if (uri.equals("luna://com.webos.service.connectionmanager/getStatus")) return netStatus();
        // getSystemSettings, setSystemSettings, turnOffScreen: nao existem no Android
        return fail("indisponivel no Android");
    }

    private static String ok() {
        return "{\"returnValue\":true}";
    }

    private static String fail(String why) {
        try {
            JSONObject o = new JSONObject();
            o.put("returnValue", false);
            o.put("errorText", why);
            return o.toString();
        } catch (Exception e) {
            return "{\"returnValue\":false}";
        }
    }

    // ---------- apps ----------

    private String listApps() throws Exception {
        PackageManager pm = act.getPackageManager();
        Map<String, JSONObject> found = new LinkedHashMap<String, JSONObject>();
        String[] cats = { Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER };
        for (String cat : cats) {
            Intent i = new Intent(Intent.ACTION_MAIN, null);
            i.addCategory(cat);
            for (ResolveInfo ri : pm.queryIntentActivities(i, 0)) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(act.getPackageName()) || found.containsKey(pkg)) continue;
                String icon = "https://" + MainActivity.HOST + "/pkgicon/" + pkg;
                JSONObject o = new JSONObject();
                o.put("id", pkg);
                o.put("title", String.valueOf(ri.loadLabel(pm)));
                o.put("icon", icon);
                o.put("largeIcon", icon);
                o.put("folderPath", "");
                found.put(pkg, o);
            }
        }
        JSONArray arr = new JSONArray();
        for (JSONObject o : found.values()) arr.put(o);
        JSONObject res = new JSONObject();
        res.put("returnValue", true);
        res.put("launchPoints", arr);
        return res.toString();
    }

    private String start(Intent i) {
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        try {
            act.startActivity(i);
            return ok();
        } catch (Throwable t) {
            return fail("nao abriu");
        }
    }

    private boolean isDefaultHome() {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_HOME);
        ResolveInfo ri = act.getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
        return ri != null && ri.activityInfo != null
                && act.getPackageName().equals(ri.activityInfo.packageName);
    }

    private String launch(JSONObject p) {
        String id = p.optString("id", "");

        if (id.equals("com.webos.app.browser")) {
            JSONObject params = p.optJSONObject("params");
            String url = params != null ? params.optString("target", "") : "";
            if (url.length() == 0) url = "https://www.google.com";
            return start(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        }
        if (id.equals("com.webos.app.home")) {
            // se somos a tela inicial, "sair" nao faz nada; se somos so um app, fecha
            if (!isDefaultHome()) {
                act.runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        act.finish();
                    }
                });
            }
            return ok();
        }
        if (id.equals("com.palm.app.settings")) {
            return start(new Intent(Settings.ACTION_SETTINGS));
        }
        if (id.equals("com.webos.app.livetv") || id.equals("com.webos.app.inputpicker")) {
            return start(new Intent(Intent.ACTION_VIEW, TvContract.Channels.CONTENT_URI));
        }
        if (id.startsWith("com.webos.app.hdmi")) {
            return openHdmi(id.charAt(id.length() - 1) - '0');
        }

        String pkg = LEGACY.containsKey(id) ? LEGACY.get(id) : id;
        PackageManager pm = act.getPackageManager();
        Intent i = pm.getLeanbackLaunchIntentForPackage(pkg);
        if (i == null) i = pm.getLaunchIntentForPackage(pkg);
        if (i == null) return fail("app nao instalado");
        return start(i);
    }

    private String openHdmi(int n) {
        try {
            TvInputManager tm = (TvInputManager) act.getSystemService(Context.TV_INPUT_SERVICE);
            if (tm == null) return fail("sem TV input");
            List<TvInputInfo> hdmi = new ArrayList<TvInputInfo>();
            for (TvInputInfo t : tm.getTvInputList()) {
                if (t.getType() == TvInputInfo.TYPE_HDMI) hdmi.add(t);
            }
            if (n < 1 || n > hdmi.size()) return fail("entrada nao encontrada");
            Uri u = TvContract.buildChannelUriForPassthroughInput(hdmi.get(n - 1).getId());
            return start(new Intent(Intent.ACTION_VIEW, u));
        } catch (Throwable t) {
            return fail("entrada indisponivel");
        }
    }

    // ---------- volume e rede ----------

    private String getVolume() throws Exception {
        AudioManager am = (AudioManager) act.getSystemService(Context.AUDIO_SERVICE);
        int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int cur = am.getStreamVolume(AudioManager.STREAM_MUSIC);
        JSONObject o = new JSONObject();
        o.put("returnValue", true);
        o.put("volume", max > 0 ? Math.round(cur * 100f / max) : 0);
        return o.toString();
    }

    private String setVolume(JSONObject p) {
        try {
            AudioManager am = (AudioManager) act.getSystemService(Context.AUDIO_SERVICE);
            int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            int v = Math.max(0, Math.min(100, p.optInt("volume", 0)));
            am.setStreamVolume(AudioManager.STREAM_MUSIC, Math.round(v * max / 100f), AudioManager.FLAG_SHOW_UI);
            return ok();
        } catch (Throwable t) {
            return fail("volume bloqueado");
        }
    }

    @SuppressWarnings("deprecation")
    private String netStatus() throws Exception {
        ConnectivityManager cm = (ConnectivityManager) act.getSystemService(Context.CONNECTIVITY_SERVICE);
        boolean wifi = false, wired = false;
        for (Network n : cm.getAllNetworks()) {
            NetworkCapabilities c = cm.getNetworkCapabilities(n);
            if (c == null) continue;
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)) wifi = true;
            if (c.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)) wired = true;
        }
        String ssid = null;
        if (wifi) {
            try {
                WifiManager wm = (WifiManager) act.getApplicationContext().getSystemService(Context.WIFI_SERVICE);
                String s = wm.getConnectionInfo().getSSID();
                if (s != null && !s.contains("unknown")) ssid = s.replace("\"", "");
            } catch (Throwable ignored) { }
        }
        JSONObject w = new JSONObject();
        w.put("state", wifi ? "connected" : "disconnected");
        if (ssid != null) w.put("ssid", ssid);
        JSONObject c = new JSONObject();
        c.put("state", wired ? "connected" : "disconnected");
        JSONObject res = new JSONObject();
        res.put("returnValue", true);
        res.put("wifi", w);
        res.put("wired", c);
        return res.toString();
    }
}
